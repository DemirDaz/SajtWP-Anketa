<?php
include("application.php");
session_start();
function getStudents()
{
global $databaseHost, $databaseUser, $databasePassword, $databaseName;
    $aDBLink = mysql_connect( $databaseHost, $databaseUser, $databasePassword );
   if ( !empty( $aDBLink ) )   
 {      // select the MySQL database
        if ( mysql_select_db( $databaseName, $aDBLink ) )        
{           $aSQL = "SELECT * FROM studenti";            $students = array();          // execute the SELECT query        
  $aQResult = mysql_query( $aSQL, $aDBLink );         
 if ( $aQResult)          {                while($aRow = mysql_fetch_array( $aQResult ))             
   {              	$students[$aRow["Indeks"]]["ImeIPrezime"] = $aRow["ImeIPrezime"];                	
$students[$aRow["Indeks"]]["Prosek"] = $aRow["Prosek"];              }          
 return $students;         }
            else       
{                print( "Query failed<br>" );             
  return false;         }     }      
 else
       {           print( "Unable to select DB<br>" );
			return false;        }    }    
else    {	print( "Unable to connect to DB<br>" );    	return false;
    }}
if (empty($_SESSION["korisnik"]))
{	print("Neovlasceni pristup stranici! <br>");
	// Umesto prekida skripta moze i redirekcija na login.php	die;}
$students = getStudents();
?>
<h1> Lista studenata </h1><table cellspacing="5">
<tr><th>Indkes</th><th>Ime i prezime</th>
<?php if ($_SESSION["korisnik"]["Privilegije"] == "admin") print ("<th>Prosek</th>"); ?> </tr>
<?php
foreach ($students as $indeks => $aValue)
{	$ime = $aValue["ImeIPrezime"];	
$prosek = $aValue["Prosek"];
	print("<tr><td>$indeks</td><td>$ime</td>");	
if ($_SESSION["korisnik"]["Privilegije"] == "admin")		
print("<td>$prosek</td>");
	print("</tr>");}
print("</table>");
print("<hr size='1' />");
print("<h1> Podaci o korisniku </h1>");
print("<b> Korisnik </b>: ".$_SESSION["korisnik"]["ImeIPrezime"]."<br/>");
print("<b> Privilegije </b>: ".$_SESSION["korisnik"]["Privilegije"]. "<br/>");
print("<a href='login.php?mode=logout'>logout</a>");
?>