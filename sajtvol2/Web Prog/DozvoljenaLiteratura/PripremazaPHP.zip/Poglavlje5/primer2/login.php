<?php
  include("application.php");
  session_start();
  
  // Ukoliko je login uspesan, ova funkcija setuje sesiju i vraca -1
  // Ukoliko je login neuspesan, ova funkcija vraca -1
  function login($username, $password)
  {
  	global $databaseHost, $databaseUser, $databasePassword, $databaseName;
    $aDBLink = mysql_connect( $databaseHost, $databaseUser, $databasePassword );
    if ( !empty( $aDBLink ) )
    {
        // select the MySQL database
        if ( mysql_select_db( $databaseName, $aDBLink ) )
        {
            $aSQL = "SELECT * FROM korisnici WHERE KorisnickoIme='$username' AND Lozinka='$password'";
            // execute the SELECT query
            $aQResult = mysql_query( $aSQL, $aDBLink );
            if ( $aQResult)
            {
                $aRow = mysql_fetch_array( $aQResult );
                if (empty($aRow))
                	return false;
                $_SESSION["korisnik"]["ImeIPrezime"]= $aRow["ImeIPrezime"];
                $_SESSION["korisnik"]["Privilegije"]= $aRow["Privilegije"];
                return true;
            }
            else
            {
                print( "Query failed<br>" );
                return false;
            }
        }
        else
        {
            print( "Unable to select DB<br>" );
			return false;
        }
    }
    else
    {
    	print( "Unable to connect to DB<br>" );
    	return false;
    }
  }
?>

<?php

if (isset($_REQUEST["mode"]))
{
	if ($_REQUEST["mode"] == "logout")
	{
		unset($_SESSION["korisnik"]);
		print("Logout completed");
	}	
	if ($_REQUEST["mode"] == "updatelogin")
	{
		$username = $_REQUEST["korisnickoime"];
		$password = $_REQUEST["lozinka"];
		if (login($username, $password))
			// Redirekcija na drugu stranu:
			header("Location: printstudents.php");
		else 
			$errorMessage = "Pogresni podaci za login.";
	}
}
?>

<HTML>
	<head></head>
	<body>
		<h1>Login</h1>
		<?php
			if (isset($errorMessage))
				print("<b>Error: $errorMessage</b><br/>");
		?>
		<form method="post" action="login.php">
			<input type="hidden" name="mode" value="updatelogin">
			<?php
				if(isset($_REQUEST["mode"]) && $_REQUEST["mode"] == "updatelogin")
					$oldUsername = $_REQUEST["korisnickoime"]; 
			?>
			<table>
			<tr><td>Korisnicko ime: </td><td><INPUT type="text" name="korisnickoime" value="<?php print($oldUsername)?>"/><td></tr>
			<tr><td>Lozinka: </td><td><INPUT type="password" name="lozinka" /></td></tr>
			</table>
			<input type="submit" value="Prosledi">
		</form>
	</body>
</HTML>