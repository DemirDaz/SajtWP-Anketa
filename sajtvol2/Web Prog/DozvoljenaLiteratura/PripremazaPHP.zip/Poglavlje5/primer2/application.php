<?php
$databaseHost = "localhost";
	$databaseName = "fakultet";
	$databaseUser = "root";
	$databasePassword = "";	
?>