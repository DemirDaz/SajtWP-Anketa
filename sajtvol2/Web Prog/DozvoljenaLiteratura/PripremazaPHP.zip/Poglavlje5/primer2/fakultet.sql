-- phpMyAdmin SQL Dump
-- version 2.9.0.3
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: May 10, 2007 at 09:01 PM
-- Server version: 5.0.27
-- PHP Version: 4.4.4
-- 
-- Database: `fakultet`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `korisnici`
-- 

CREATE TABLE `korisnici` (
  `Id` int(11) NOT NULL auto_increment,
  `KorisnickoIme` varchar(30) NOT NULL,
  `Lozinka` varchar(50) NOT NULL,
  `ImeIPrezime` varchar(50) NOT NULL,
  `Privilegije` enum('admin','user') NOT NULL,
  PRIMARY KEY  (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- 
-- Dumping data for table `korisnici`
-- 

INSERT INTO `korisnici` (`Id`, `KorisnickoIme`, `Lozinka`, `ImeIPrezime`, `Privilegije`) VALUES 
(1, 'user1', 'user1', 'Petar Petrovic', 'user'),
(2, 'user2', 'user2', 'Janko Jankovic', 'admin');

-- --------------------------------------------------------

-- 
-- Table structure for table `studenti`
-- 

CREATE TABLE `studenti` (
  `Indeks` int(11) NOT NULL,
  `ImeIPrezime` varchar(50) NOT NULL,
  `Prosek` decimal(10,0) NOT NULL,
  PRIMARY KEY  (`Indeks`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `studenti`
-- 

INSERT INTO `studenti` (`Indeks`, `ImeIPrezime`, `Prosek`) VALUES 
(11111, 'Mirko Mirkovic', '8'),
(12345, 'Petar Simic', '9'),
(22222, 'Marko Markovic', '9');
