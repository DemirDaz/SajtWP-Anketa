<?php
    session_start();
?>
<html>
<head>
	<title>Getting Started With Sessions: Page 2</title>
</head>
<body>
<?php
    print( "Current User: ".$_SESSION["aUser"]."<br>" );
    print( "Current Account: ".$_SESSION["aAccount"]."<br>" );
?>
</body>
</html>
