<?php
	//print("Pre nego sto se sesija startuje ne sme da se nalazi HTML kod ili print naredba");
    session_start();
    $_SESSION["aUser"]='Pera';
    $_SESSION["aAccount"]='1016';
?>
<html>
<head>
	<title>Getting Started With Sessions: Page 1</title>
</head>
<body>
<?php
    print( "Current User: ".$_SESSION["aUser"]."<br>" );
    print( "Current Account: ".$_SESSION["aAccount"]."<br>" );
?>
    <br><br>
    <a href="listing2.php">Go to page 2</a>
</body>
</html>
