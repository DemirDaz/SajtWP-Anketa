function Login()
{
	// javni atributi klase se pisu sa this prefiksom
	// privatni atribut: var parent;
	this.parent;
	this.adresaPrijave = "prijava.php";
	
	
	this.Nacrtaj = function(id)
	{

		// na osnovu navedenog id-a uhvatiti HTML element i referencu zapamtiti u this.parent
		
		this.parent = document.getElementById(id);

		// ukoliko ne postoji element sa tim id-om, javiti gresku i prekinuti
		
		if ( this.parent == null ) 
		{
			alert("Navedeni element ne postoji!");
			return;
		}
		
		// napraviti novi element, FORM (obrazac)
		var el = document.createElement("form");
		el.style.backgroundColor = "#bbbbbb";
		el.style.border = "1px #333333 dashed";
		el.action = this.adresaPrijave;				// odrediti adresu prijave (action atribut FORM elementa)
		
		// dodeliti sadrzaj FORM elementu. Generalno moze se izvesti na dva nacina: dodeljivanjem tekstualnog
		// niza innerHTML atributu, ili dodavanjem pomocu DOM-a (kao sto je dodat FORM element)
		
		var t = "Korisničko ime <br /> <input type='text' name='ime' value='unesi tekst' /><br />";
		t += "Šifra <br /> <input type='password' /><br />";
		t += "<input type='submit' value='Prijava'/>";
		el.innerHTML = t;
		
		// dodavanje novog (FORM) elementa roditeljskom elementu
		 
		this.parent.appendChild(el);
		
		
	}

	
}